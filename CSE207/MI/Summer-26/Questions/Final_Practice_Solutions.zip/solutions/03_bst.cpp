/* ============================================================
   CSE207 Practice - Part 3 : BINARY SEARCH TREE (Problems 13 - 20)
   Compile: g++ 03_bst.cpp -o 03_bst
   ============================================================ */
#include <iostream>
using namespace std;

struct Node {
    int   data;
    Node *left, *right;
};

Node* newNode(int d)
{
    Node *p  = new Node;
    p->data  = d;
    p->left  = NULL;
    p->right = NULL;
    return p;
}

/* ---------------- standard BST insert ---------------- */
Node* insert(Node *root, int key)
{
    if (root == NULL) return newNode(key);       /* empty spot found */
    if (key < root->data)
        root->left  = insert(root->left,  key);  /* smaller -> left  */
    else if (key > root->data)
        root->right = insert(root->right, key);  /* larger  -> right */
    return root;                                 /* duplicates ignored */
}

void inorder(Node *r) { if (r) { inorder(r->left); cout << r->data << " "; inorder(r->right); } }

/* sideways picture: root at the left, right subtree printed on top */
void printTree(Node *r, int depth)
{
    if (r == NULL) return;
    printTree(r->right, depth + 1);
    for (int i = 0; i < depth; i++) cout << "      ";
    cout << r->data << "\n";
    printTree(r->left, depth + 1);
}

/* ------------------------------------------------------------
   Problem 13 : array -> BST (insert in the given order), then
                test whether the BST is NEAR-COMPLETE (= complete):
                every level full except possibly the last, and the
                last level filled from the left.

   Trick: number the nodes like a heap (root = 0, children 2i+1 /
   2i+2). The tree is complete <=> every index stays below n.
   ------------------------------------------------------------ */
int countNodes(Node *r) { return r == NULL ? 0 : 1 + countNodes(r->left) + countNodes(r->right); }

bool checkIndex(Node *r, int index, int n)
{
    if (r == NULL) return true;
    if (index >= n) return false;                /* a hole was left behind */
    return checkIndex(r->left,  2 * index + 1, n)
        && checkIndex(r->right, 2 * index + 2, n);
}

bool isNearComplete(Node *root) { return checkIndex(root, 0, countNodes(root)); }

Node* arrayToBST(int a[], int n)
{
    Node *root = NULL;
    for (int i = 0; i < n; i++) root = insert(root, a[i]);
    return root;
}

/* ------------------------------------------------------------
   Problem 14 : print every node that has AT LEAST ONE child
   ------------------------------------------------------------ */
void printNodesWithChild(Node *root)
{
    if (root == NULL) return;
    if (root->left != NULL || root->right != NULL)   /* not a leaf */
        cout << root->data << " ";
    printNodesWithChild(root->left);
    printNodesWithChild(root->right);
}

/* ------------------------------------------------------------
   Problem 15 : from the PREORDER of a BST, does every non-leaf
                node have exactly ONE child ?

   METHOD 1 (the simple one) - rebuild the tree, then traverse it.
   Inserting the preorder values in the order they are given rebuilds
   the ORIGINAL BST exactly: preorder lists a node after all of its
   ancestors, so by the time a value is inserted its whole search
   path already exists and it lands in the right place.
   Once the tree is back, the question is a plain traversal - does
   any node have BOTH children?
   ------------------------------------------------------------ */
Node* buildFromPreorder(int pre[], int n)
{
    Node *root = NULL;
    for (int i = 0; i < n; i++)
        root = insert(root, pre[i]);        /* same insert as Problem 13 */
    return root;
}

bool everyNonLeafHasOneChild(Node *root)
{
    if (root == NULL) return true;                          /* empty  -> fine */
    if (root->left != NULL && root->right != NULL)
        return false;                                       /* two children   */

    return everyNonLeafHasOneChild(root->left)              /* check the rest */
        && everyNonLeafHasOneChild(root->right);
}

/* ------------------------------------------------------------
   Problem 15, METHOD 2 - one scan of the array, no tree at all.

   Walk the preorder from the RIGHT, keeping the smallest (mn) and
   largest (mx) value seen so far. In a one-child chain each earlier
   node must fall OUTSIDE [mn, mx] - it is either a new minimum or a
   new maximum. A value landing inside the range would need both a
   left and a right child.
   ------------------------------------------------------------ */
bool hasOnlyOneChild(int pre[], int n)
{
    if (n <= 2) return true;

    int mn, mx;
    if (pre[n - 1] > pre[n - 2]) { mx = pre[n - 1]; mn = pre[n - 2]; }
    else                         { mx = pre[n - 2]; mn = pre[n - 1]; }

    for (int i = n - 3; i >= 0; i--) {
        if      (pre[i] < mn) mn = pre[i];       /* new minimum -> ok */
        else if (pre[i] > mx) mx = pre[i];       /* new maximum -> ok */
        else                  return false;      /* inside range -> 2 children */
    }
    return true;
}

/* ------------------------------------------------------------
   Problem 16 : SECOND LARGEST element of a BST
   Reverse inorder (right, root, left) gives values in decreasing
   order - stop as soon as the 2nd one has been visited.
   ------------------------------------------------------------ */
void secondLargestUtil(Node *root, int &count, int &result)
{
    if (root == NULL || count >= 2) return;

    secondLargestUtil(root->right, count, result);   /* larger side first */
    if (count >= 2) return;

    count++;
    if (count == 2) { result = root->data; return; }

    secondLargestUtil(root->left, count, result);
}

bool secondLargest(Node *root, int &out)
{
    int count = 0, result = 0;
    secondLargestUtil(root, count, result);
    if (count < 2) return false;                 /* fewer than 2 nodes */
    out = result;
    return true;
}

/* ------------------------------------------------------------
   Problem 17 : SECOND SMALLEST element of a BST
   Plain inorder (left, root, right) - stop at the 2nd node.
   ------------------------------------------------------------ */
void secondSmallestUtil(Node *root, int &count, int &result)
{
    if (root == NULL || count >= 2) return;

    secondSmallestUtil(root->left, count, result);   /* smaller side first */
    if (count >= 2) return;

    count++;
    if (count == 2) { result = root->data; return; }

    secondSmallestUtil(root->right, count, result);
}

bool secondSmallest(Node *root, int &out)
{
    int count = 0, result = 0;
    secondSmallestUtil(root, count, result);
    if (count < 2) return false;
    out = result;
    return true;
}

/* ------------------------------------------------------------
   Problem 18 : THIRD LARGEST, without storing the inorder in an
                array.  Same reverse-inorder walk, counter = 3.
                Only two extra variables are used -> O(1) memory
                apart from the recursion stack.
   ------------------------------------------------------------ */
void kthLargestUtil(Node *root, int k, int &count, int &result)
{
    if (root == NULL || count >= k) return;

    kthLargestUtil(root->right, k, count, result);
    if (count >= k) return;

    count++;
    if (count == k) { result = root->data; return; }

    kthLargestUtil(root->left, k, count, result);
}

bool kthLargest(Node *root, int k, int &out)
{
    int count = 0, result = 0;
    kthLargestUtil(root, k, count, result);
    if (count < k) return false;
    out = result;
    return true;
}

/* ------------------------------------------------------------
   Problem 19 : does a binary tree satisfy the BST property ?
   Every node must lie strictly inside the (min, max) window
   inherited from its ancestors.
   ------------------------------------------------------------ */
bool isBSTUtil(Node *root, int mn, int mx)
{
    if (root == NULL) return true;
    if (root->data <= mn || root->data >= mx) return false;

    return isBSTUtil(root->left,  mn, root->data)    /* left  < node */
        && isBSTUtil(root->right, root->data, mx);   /* right > node */
}

bool isBST(Node *root) { return isBSTUtil(root, -2147483647 - 1, 2147483647); }

/* ------------------------------------------------------------
   Problem 20 : inorder PREDECESSOR and SUCCESSOR of a key
   Walk down from the root:
      going right  -> the node just left behind is a predecessor
      going left   -> the node just left behind is a successor
   If the key is found and has a left subtree, its predecessor is
   the maximum of that subtree; with a right subtree, its successor
   is the minimum of that subtree.
   ------------------------------------------------------------ */
void findPreSuc(Node *root, int key, Node *&pre, Node *&suc)
{
    pre = NULL;
    suc = NULL;
    Node *cur = root;

    while (cur != NULL) {
        if (key == cur->data) {
            if (cur->left != NULL) {                     /* max of left subtree */
                Node *t = cur->left;
                while (t->right != NULL) t = t->right;
                pre = t;
            }
            if (cur->right != NULL) {                    /* min of right subtree */
                Node *t = cur->right;
                while (t->left != NULL) t = t->left;
                suc = t;
            }
            return;
        }
        if (key < cur->data) { suc = cur; cur = cur->left;  }  /* cur may be successor */
        else                 { pre = cur; cur = cur->right; }  /* cur may be predecessor */
    }
}

/* ============================ DEMO ============================ */
int main()
{
    /* ---------------- Problem 13 ---------------- */
    int a1[] = { 50, 30, 70, 20, 40, 60, 80 };            /* perfectly balanced */
    int a2[] = { 50, 30, 70, 20, 80 };                    /* has a hole         */

    Node *b1 = arrayToBST(a1, 7);
    Node *b2 = arrayToBST(a2, 5);

    cout << "P13) Array {50,30,70,20,40,60,80} -> BST\n";
    printTree(b1, 1);
    cout << "     inorder : "; inorder(b1); cout << "\n";
    cout << "     near-complete ? " << (isNearComplete(b1) ? "YES" : "NO") << "\n\n";

    cout << "     Array {50,30,70,20,80} -> BST\n";
    printTree(b2, 1);
    cout << "     near-complete ? " << (isNearComplete(b2) ? "YES" : "NO")
         << "   (80 sits at index 6 while only 5 nodes exist)\n\n";

    /* ---------------- Problem 14 ---------------- */
    int a14[] = { 50, 20, 70, 10, 45, 80 };
    Node *b14 = arrayToBST(a14, 6);
    cout << "P14) BST 50(20(10,45), 70(-,80))\n";
    cout << "     nodes having at least one child : ";
    printNodesWithChild(b14);
    cout << "\n\n";

    /* ---------------- Problem 15 ---------------- */
    int pre15a[] = { 20, 10, 11, 13, 12 };
    int pre15b[] = { 20, 10, 30, 25 };
    Node *t15a = buildFromPreorder(pre15a, 5);
    Node *t15b = buildFromPreorder(pre15b, 4);

    cout << "P15) pre = {20,10,11,13,12} rebuilt as\n";
    printTree(t15a, 2);
    cout << "     method 1 (rebuild + traverse) -> "
         << (everyNonLeafHasOneChild(t15a) ? "Yes" : "No") << "\n";
    cout << "     method 2 (single array scan)  -> "
         << (hasOnlyOneChild(pre15a, 5) ? "Yes" : "No") << "\n\n";

    cout << "     pre = {20,10,30,25} rebuilt as\n";
    printTree(t15b, 2);
    cout << "     method 1 (rebuild + traverse) -> "
         << (everyNonLeafHasOneChild(t15b) ? "Yes" : "No") << "\n";
    cout << "     method 2 (single array scan)  -> "
         << (hasOnlyOneChild(pre15b, 4) ? "Yes" : "No")
         << "   (20 has two children)\n\n";

    /* ---------------- Problem 16 ---------------- */
    int e1[] = { 10, 5 };
    int e2[] = { 10, 5, 20, 30 };
    Node *s1 = arrayToBST(e1, 2);
    Node *s2 = arrayToBST(e2, 4);
    int val;
    cout << "P16) BST {10,5}          second largest = ";
    if (secondLargest(s1, val)) cout << val << "\n"; else cout << "does not exist\n";
    cout << "     BST {10,5,20,30}    second largest = ";
    if (secondLargest(s2, val)) cout << val << "\n"; else cout << "does not exist\n";
    cout << "\n";

    /* ---------------- Problem 17 ---------------- */
    int f1[] = { 10, 5, 15 };
    int f2[] = { 10, 5, 20, 2, 30 };
    Node *m1 = arrayToBST(f1, 3);
    Node *m2 = arrayToBST(f2, 5);
    cout << "P17) BST {10,5,15}       second smallest = ";
    if (secondSmallest(m1, val)) cout << val << "\n"; else cout << "does not exist\n";
    cout << "     BST {10,5,20,2,30}  second smallest = ";
    if (secondSmallest(m2, val)) cout << val << "\n"; else cout << "does not exist\n";
    cout << "\n";

    /* ---------------- Problem 18 ---------------- */
    cout << "P18) BST {50,30,70,20,40,60,80}\n";
    cout << "     inorder (for checking) : "; inorder(b1); cout << "\n";
    if (kthLargest(b1, 3, val)) cout << "     third largest = " << val << "\n";
    else                        cout << "     third largest does not exist\n";
    cout << "\n";

    /* ---------------- Problem 19 ---------------- */
    cout << "P19) is the BST of P13 a valid BST ? " << (isBST(b1) ? "YES" : "NO") << "\n";

    Node *bad = newNode(10);                 /* 12 sits in the LEFT subtree -> invalid */
    bad->left  = newNode(5);
    bad->right = newNode(15);
    bad->left->right = newNode(12);
    cout << "     tree 10(5(-,12),15) valid ?      " << (isBST(bad) ? "YES" : "NO")
         << "   (12 > 10 but lies on the left)\n\n";

    /* ---------------- Problem 20 ---------------- */
    Node *pre = NULL, *suc = NULL;
    int keys[] = { 40, 50, 20, 80 };
    cout << "P20) BST {50,30,70,20,40,60,80}, inorder = 20 30 40 50 60 70 80\n";
    for (int i = 0; i < 4; i++) {
        findPreSuc(b1, keys[i], pre, suc);
        cout << "     key " << keys[i] << " -> predecessor = ";
        if (pre) cout << pre->data; else cout << "none";
        cout << " , successor = ";
        if (suc) cout << suc->data; else cout << "none";
        cout << "\n";
    }
    return 0;
}
