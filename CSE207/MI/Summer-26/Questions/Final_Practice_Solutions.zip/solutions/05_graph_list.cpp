/* ============================================================
   CSE207 Practice - Part 5 : GRAPH with ADJACENCY LIST (linked list)
   Problems 25, 26, 27, 31, 32, 33, 34, 35
   Compile: g++ 05_graph_list.cpp -o 05_graph_list
   ============================================================ */
#include <iostream>
using namespace std;

const int MAX = 20;

struct ListNode {
    int       vertex;
    ListNode *next;
};

struct Graph {
    int       n;                 /* how many vertex slots exist        */
    ListNode *adj[MAX];          /* adj[i] = list of neighbours of i   */
    bool      alive[MAX];        /* false once the vertex is deleted   */
};

/* ------------------------------------------------------------
   Problem 25 : create an undirected graph as an adjacency list
   ------------------------------------------------------------ */
void initGraph(Graph &g, int n)
{
    g.n = n;
    for (int i = 0; i < n; i++) { g.adj[i] = NULL; g.alive[i] = true; }
}

/* new neighbour goes at the TAIL, so the list keeps insertion order */
void appendTail(ListNode *&head, int v)
{
    ListNode *p = new ListNode;
    p->vertex = v;
    p->next   = NULL;

    if (head == NULL) { head = p; return; }

    ListNode *t = head;
    while (t->next != NULL) t = t->next;
    t->next = p;
}

/* ------------------------------------------------------------
   Problem 26 : add an edge between two existing vertices
   Undirected -> u is stored in v's list AND v in u's list.
   ------------------------------------------------------------ */
void addEdge(Graph &g, int u, int v)
{
    if (u < 0 || v < 0 || u >= g.n || v >= g.n) return;
    if (!g.alive[u] || !g.alive[v])             return;

    appendTail(g.adj[u], v);
    appendTail(g.adj[v], u);
}

void displayGraph(Graph &g)
{
    for (int i = 0; i < g.n; i++) {
        if (!g.alive[i]) continue;              /* skip deleted vertices */
        cout << i;
        for (ListNode *t = g.adj[i]; t != NULL; t = t->next)
            cout << " -> " << t->vertex;
        cout << "\n";
    }
}

/* remove ONE occurrence of value v from a linked list */
void removeFromList(ListNode *&head, int v)
{
    ListNode *cur = head, *prev = NULL;

    while (cur != NULL && cur->vertex != v) { prev = cur; cur = cur->next; }
    if (cur == NULL) return;                    /* not present */

    if (prev == NULL) head       = cur->next;   /* it was the first node */
    else              prev->next = cur->next;
    delete cur;
}

/* ------------------------------------------------------------
   Problem 27 : remove an edge between two vertices
   ------------------------------------------------------------ */
void removeEdge(Graph &g, int u, int v)
{
    removeFromList(g.adj[u], v);
    removeFromList(g.adj[v], u);
}

/* ------------------------------------------------------------
   Problem 31 : display all neighbours of one vertex
   ------------------------------------------------------------ */
void printNeighbours(Graph &g, int v)
{
    cout << "Neighbors of " << v << ": ";
    for (ListNode *t = g.adj[v]; t != NULL; t = t->next) cout << t->vertex << " ";
    cout << "\n";
}

/* ------------------------------------------------------------
   Problem 32 : search for a vertex and report whether it exists
   Here the vertices carry labels (10, 20, 30, ...) kept in a
   linked list, so the search walks that list.
   ------------------------------------------------------------ */
bool searchVertex(ListNode *vertexList, int key)
{
    for (ListNode *t = vertexList; t != NULL; t = t->next)
        if (t->vertex == key) return true;
    return false;
}

/* ------------------------------------------------------------
   Problem 33 : total number of edges in an undirected graph
   Each edge is stored twice, so add up all list lengths and halve.
   ------------------------------------------------------------ */
int countEdges(Graph &g)
{
    int total = 0;
    for (int i = 0; i < g.n; i++) {
        if (!g.alive[i]) continue;
        for (ListNode *t = g.adj[i]; t != NULL; t = t->next) total++;
    }
    return total / 2;
}

/* ------------------------------------------------------------
   Problem 34 : insert a NEW vertex and connect it to given vertices
   ------------------------------------------------------------ */
int insertVertex(Graph &g, int connectTo[], int k)
{
    int id = g.n;                               /* the new vertex number */
    g.adj[id]   = NULL;
    g.alive[id] = true;
    g.n++;

    for (int i = 0; i < k; i++) addEdge(g, id, connectTo[i]);
    return id;
}

/* ------------------------------------------------------------
   Problem 35 : delete a vertex together with all its edges
   Step 1 - for every neighbour, erase this vertex from its list
   Step 2 - throw away this vertex's own list
   Step 3 - mark the vertex dead so it is no longer displayed
   ------------------------------------------------------------ */
void deleteVertex(Graph &g, int v)
{
    if (v < 0 || v >= g.n || !g.alive[v]) return;

    for (ListNode *t = g.adj[v]; t != NULL; t = t->next)
        removeFromList(g.adj[t->vertex], v);    /* step 1 */

    ListNode *cur = g.adj[v];                   /* step 2 */
    while (cur != NULL) { ListNode *nx = cur->next; delete cur; cur = nx; }

    g.adj[v]   = NULL;
    g.alive[v] = false;                         /* step 3 */
}

/* ============================ DEMO ============================ */
int main()
{
    /* ---------------- Problem 25 ---------------- */
    /* n = 4, e = 4, edges 0-1, 0-2, 1-2, 2-3 */
    Graph g;
    initGraph(g, 4);
    addEdge(g, 0, 1);
    addEdge(g, 0, 2);
    addEdge(g, 1, 2);
    addEdge(g, 2, 3);

    cout << "P25) Adjacency list (n=4, edges 0-1 0-2 1-2 2-3)\n";
    displayGraph(g);
    cout << "\n";

    /* ---------------- Problem 26 ---------------- */
    Graph g26;
    initGraph(g26, 4);
    addEdge(g26, 1, 2);                          /* start: 2 -> 1 only */
    cout << "P26) before adding edge 2-3\n";
    displayGraph(g26);
    addEdge(g26, 2, 3);
    cout << "     after adding edge 2-3\n";
    displayGraph(g26);
    cout << "\n";

    /* ---------------- Problem 27 ---------------- */
    Graph g27;
    initGraph(g27, 4);
    addEdge(g27, 0, 1);
    addEdge(g27, 0, 2);
    addEdge(g27, 1, 2);
    addEdge(g27, 2, 3);
    cout << "P27) before deleting edge 1-2\n";
    displayGraph(g27);
    removeEdge(g27, 1, 2);
    cout << "     after deleting edge 1-2\n";
    displayGraph(g27);
    cout << "\n";

    /* ---------------- Problem 31 ---------------- */
    /* n = 4, e = 3, edges 0-1, 1-3, 0-2 ; show neighbours of 1 */
    Graph g31;
    initGraph(g31, 4);
    addEdge(g31, 0, 1);
    addEdge(g31, 1, 3);
    addEdge(g31, 0, 2);
    cout << "P31) ";
    printNeighbours(g31, 1);
    cout << "\n";

    /* ---------------- Problem 32 ---------------- */
    ListNode *vlist = NULL;
    int labels[] = { 10, 20, 30, 40, 50 };
    for (int i = 0; i < 5; i++) appendTail(vlist, labels[i]);

    cout << "P32) vertices 10 20 30 40 50\n";
    cout << "     Search 30 : " << (searchVertex(vlist, 30) ? "Found" : "Not Found") << "\n";
    cout << "     Search 35 : " << (searchVertex(vlist, 35) ? "Found" : "Not Found") << "\n\n";

    /* ---------------- Problem 33 ---------------- */
    cout << "P33) Total edges = " << countEdges(g) << "\n\n";

    /* ---------------- Problem 34 ---------------- */
    /* n = 3, e = 2, edges 0-1, 1-2 ; new vertex joined to 1 and 2 */
    Graph g34;
    initGraph(g34, 3);
    addEdge(g34, 0, 1);
    addEdge(g34, 1, 2);
    cout << "P34) before inserting the new vertex\n";
    displayGraph(g34);

    int conn[] = { 1, 2 };
    int id = insertVertex(g34, conn, 2);
    cout << "     after inserting vertex " << id << " joined to 1 and 2\n";
    displayGraph(g34);
    cout << "\n";

    /* ---------------- Problem 35 ---------------- */
    /* n = 4, e = 4, edges 0-1, 0-2, 1-3, 2-3 ; delete vertex 1 */
    Graph g35;
    initGraph(g35, 4);
    addEdge(g35, 0, 1);
    addEdge(g35, 0, 2);
    addEdge(g35, 1, 3);
    addEdge(g35, 2, 3);
    cout << "P35) before deleting vertex 1\n";
    displayGraph(g35);
    deleteVertex(g35, 1);
    cout << "     after deleting vertex 1\n";
    displayGraph(g35);
    return 0;
}
