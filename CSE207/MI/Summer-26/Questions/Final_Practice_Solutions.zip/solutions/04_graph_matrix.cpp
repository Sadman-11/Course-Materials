/* ============================================================
   CSE207 Practice - Part 4 : GRAPH with ADJACENCY MATRIX
   Problems 24, 28, 29, 30, 36, 37, 38, 39, 40
   Compile: g++ 04_graph_matrix.cpp -o 04_graph_matrix
   ============================================================ */
#include <iostream>
using namespace std;

const int MAX = 20;

/* ------------------------------------------------------------
   Problem 24 : build an UNDIRECTED graph as an adjacency matrix
   An undirected edge (u,v) sets BOTH  m[u][v]  and  m[v][u].
   ------------------------------------------------------------ */
void initMatrix(int m[MAX][MAX], int n)
{
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            m[i][j] = 0;
}

void addEdgeU(int m[MAX][MAX], int u, int v)     /* undirected */
{
    m[u][v] = 1;
    m[v][u] = 1;
}

void addEdgeD(int m[MAX][MAX], int u, int v)     /* directed: u -> v only */
{
    m[u][v] = 1;
}

void displayMatrix(int m[MAX][MAX], int n)
{
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) cout << m[i][j];
        cout << "\n";
    }
}

/* ------------------------------------------------------------
   Problem 28 : are two vertices directly connected (adjacent) ?
   ------------------------------------------------------------ */
bool isAdjacent(int m[MAX][MAX], int u, int v) { return m[u][v] == 1; }

/* ------------------------------------------------------------
   Problem 29 : degree of every vertex (undirected)
   degree(i) = number of 1s in row i
   ------------------------------------------------------------ */
void printDegrees(int m[MAX][MAX], int n)
{
    for (int i = 0; i < n; i++) {
        int deg = 0;
        for (int j = 0; j < n; j++) deg += m[i][j];
        cout << i << " -> " << deg << "\n";
    }
}

/* ------------------------------------------------------------
   Problem 30 : indegree and outdegree of every vertex (directed)
   outdegree(i) = 1s in ROW i        indegree(i) = 1s in COLUMN i
   ------------------------------------------------------------ */
void printInOutDegrees(int m[MAX][MAX], int n)
{
    for (int i = 0; i < n; i++) {
        int in = 0, out = 0;
        for (int j = 0; j < n; j++) {
            out += m[i][j];                      /* row    -> outgoing */
            in  += m[j][i];                      /* column -> incoming */
        }
        cout << i << " -> In: " << in << " Out: " << out << "\n";
    }
}

/* ------------------------------------------------------------
   Problem 36 : count the edges of an undirected graph straight
                from the matrix (no edge list allowed)
   Every edge appears twice, so only the upper triangle is read.
   A self-loop m[i][i] counts as one edge.
   ------------------------------------------------------------ */
int countEdges(int m[MAX][MAX], int n)
{
    int count = 0;
    for (int i = 0; i < n; i++)
        for (int j = i; j < n; j++)              /* j starts at i */
            if (m[i][j] == 1) count++;
    return count;
}

/* ------------------------------------------------------------
   Problem 37 : list all ISOLATED vertices (degree 0)
   ------------------------------------------------------------ */
void printIsolated(int m[MAX][MAX], int n)
{
    bool found = false;
    for (int i = 0; i < n; i++) {
        int deg = 0;
        for (int j = 0; j < n; j++) deg += m[i][j];
        if (deg == 0) { cout << i << " "; found = true; }
    }
    if (!found) cout << "(none)";
    cout << "\n";
}

/* ------------------------------------------------------------
   Problem 38 : adjacency MATRIX  ->  adjacency LIST
   ------------------------------------------------------------ */
struct ListNode {
    int       vertex;
    ListNode *next;
};

void appendTail(ListNode *&head, int v)          /* keeps vertices in order */
{
    ListNode *p = new ListNode;
    p->vertex = v;
    p->next   = NULL;

    if (head == NULL) { head = p; return; }

    ListNode *t = head;
    while (t->next != NULL) t = t->next;
    t->next = p;
}

void matrixToList(int m[MAX][MAX], int n, ListNode *adj[])
{
    for (int i = 0; i < n; i++) adj[i] = NULL;

    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            if (m[i][j] == 1) appendTail(adj[i], j);
}

void displayList(ListNode *adj[], int n)
{
    for (int i = 0; i < n; i++) {
        cout << i;
        for (ListNode *t = adj[i]; t != NULL; t = t->next) cout << " -> " << t->vertex;
        cout << "\n";
    }
}

/* ------------------------------------------------------------
   Problem 39 : does the graph contain a SELF-LOOP ?
   A self-loop means a 1 on the main diagonal.
   ------------------------------------------------------------ */
bool hasSelfLoop(int m[MAX][MAX], int n)
{
    for (int i = 0; i < n; i++)
        if (m[i][i] == 1) return true;
    return false;
}

/* ------------------------------------------------------------
   Problem 40 : delete a vertex from the matrix
   Shift every later row up and every later column left, then the
   graph has n-1 vertices (they are renumbered).
   ------------------------------------------------------------ */
int deleteVertex(int m[MAX][MAX], int n, int del)
{
    if (del < 0 || del >= n) return n;           /* nothing to do */

    for (int i = del; i < n - 1; i++)            /* shift rows up   */
        for (int j = 0; j < n; j++)
            m[i][j] = m[i + 1][j];

    for (int j = del; j < n - 1; j++)            /* shift columns left */
        for (int i = 0; i < n; i++)
            m[i][j] = m[i][j + 1];

    return n - 1;                                /* new vertex count */
}

/* ============================ DEMO ============================ */
int main()
{
    int m[MAX][MAX];

    /* ---------------- Problem 24 ---------------- */
    /* n = 4, e = 4, edges 0-1, 0-2, 1-2, 2-3 */
    int n = 4;
    initMatrix(m, n);
    addEdgeU(m, 0, 1);
    addEdgeU(m, 0, 2);
    addEdgeU(m, 1, 2);
    addEdgeU(m, 2, 3);

    cout << "P24) Adjacency matrix (n=4, edges 0-1 0-2 1-2 2-3)\n";
    displayMatrix(m, n);
    cout << "\n";

    /* ---------------- Problem 28 ---------------- */
    /* n = 4, e = 3, edges 0-1, 1-2, 2-3 ; check 1 and 2 */
    int t[MAX][MAX];
    initMatrix(t, 4);
    addEdgeU(t, 0, 1);
    addEdgeU(t, 1, 2);
    addEdgeU(t, 2, 3);
    cout << "P28) Check 1 2 : " << (isAdjacent(t, 1, 2) ? "Adjacent" : "Not Adjacent") << "\n";
    cout << "     Check 0 3 : " << (isAdjacent(t, 0, 3) ? "Adjacent" : "Not Adjacent") << "\n\n";

    /* ---------------- Problem 29 ---------------- */
    /* n = 5, e = 4, edges 0-1, 0-2, 1-3, 1-4 */
    int d[MAX][MAX];
    initMatrix(d, 5);
    addEdgeU(d, 0, 1);
    addEdgeU(d, 0, 2);
    addEdgeU(d, 1, 3);
    addEdgeU(d, 1, 4);
    cout << "P29) Degree of each vertex\n";
    printDegrees(d, 5);
    cout << "\n";

    /* ---------------- Problem 30 ---------------- */
    /* directed, n = 4, e = 5 : 0->1 0->2 1->2 2->3 3->1 */
    int g[MAX][MAX];
    initMatrix(g, 4);
    addEdgeD(g, 0, 1);
    addEdgeD(g, 0, 2);
    addEdgeD(g, 1, 2);
    addEdgeD(g, 2, 3);
    addEdgeD(g, 3, 1);
    cout << "P30) Indegree / outdegree (directed graph)\n";
    printInOutDegrees(g, 4);
    cout << "\n";

    /* ---------------- Problem 36 ---------------- */
    cout << "P36) Edges counted from the P24 matrix = " << countEdges(m, n) << "\n\n";

    /* ---------------- Problem 37 ---------------- */
    int iso[MAX][MAX];
    initMatrix(iso, 5);
    addEdgeU(iso, 0, 1);
    addEdgeU(iso, 1, 2);                          /* 3 and 4 stay isolated */
    cout << "P37) Graph n=5 with edges 0-1, 1-2\n";
    cout << "     isolated vertices : ";
    printIsolated(iso, 5);
    cout << "\n";

    /* ---------------- Problem 38 ---------------- */
    ListNode *adj[MAX];
    matrixToList(m, n, adj);
    cout << "P38) The P24 matrix converted to an adjacency list\n";
    displayList(adj, n);
    cout << "\n";

    /* ---------------- Problem 39 ---------------- */
    cout << "P39) P24 graph has a self-loop ? " << (hasSelfLoop(m, n) ? "YES" : "NO") << "\n";
    int sl[MAX][MAX];
    initMatrix(sl, 3);
    addEdgeU(sl, 0, 1);
    sl[2][2] = 1;                                 /* vertex 2 loops on itself */
    cout << "     after setting m[2][2] = 1     ? " << (hasSelfLoop(sl, 3) ? "YES" : "NO") << "\n\n";

    /* ---------------- Problem 40 ---------------- */
    cout << "P40) Delete vertex 1 from the P24 graph\n";
    cout << "     before :\n";
    displayMatrix(m, n);
    n = deleteVertex(m, n, 1);
    cout << "     after  (remaining vertices renumbered from 0) :\n";
    displayMatrix(m, n);
    cout << "     remaining vertices = " << n << "\n";
    return 0;
}
