/* ============================================================
   CSE207 Practice - Part 6 : HEAP  (Problems 41 - 45)
   Compile: g++ 06_heap.cpp -o 06_heap
   ============================================================
   Array layout used everywhere (0-based):
        parent(i)      = (i - 1) / 2
        left child(i)  = 2*i + 1
        right child(i) = 2*i + 2
   ============================================================ */
#include <iostream>
using namespace std;

const int MAX = 50;

void swapInt(int &a, int &b) { int t = a; a = b; b = t; }

void printArray(int a[], int n)
{
    cout << "[ ";
    for (int i = 0; i < n; i++) cout << a[i] << " ";
    cout << "]\n";
}

/* draws the heap sideways: root on the left, right child on top */
void drawHeap(int a[], int n, int i, int depth)
{
    if (i >= n) return;
    drawHeap(a, n, 2 * i + 2, depth + 1);
    for (int k = 0; k < depth; k++) cout << "        ";
    cout << a[i] << "\n";
    drawHeap(a, n, 2 * i + 1, depth + 1);
}

/* ------------------------------------------------------------
   Problem 41 : build a MAX heap by inserting one value at a time
   New value goes to the end, then "swims up" while it is larger
   than its parent.
   ------------------------------------------------------------ */
void insertMaxHeap(int heap[], int &n, int value)
{
    heap[n] = value;                 /* put it at the first free slot */
    int i   = n;
    n++;

    while (i > 0 && heap[(i - 1) / 2] < heap[i]) {   /* bigger than parent? */
        swapInt(heap[i], heap[(i - 1) / 2]);
        i = (i - 1) / 2;                             /* move up one level  */
    }
}

/* ------------------------------------------------------------
   Problem 43 : insert into a MIN heap (same idea, reversed test)
   ------------------------------------------------------------ */
void insertMinHeap(int heap[], int &n, int value)
{
    heap[n] = value;
    int i   = n;
    n++;

    while (i > 0 && heap[(i - 1) / 2] > heap[i]) {   /* smaller than parent? */
        swapInt(heap[i], heap[(i - 1) / 2]);
        i = (i - 1) / 2;
    }
}

/* ------------------------------------------------------------
   heapify (sift down) for a MAX heap - the engine of 42, 44, 45
   ------------------------------------------------------------ */
void maxHeapify(int a[], int n, int i)
{
    int largest = i;
    int l = 2 * i + 1;
    int r = 2 * i + 2;

    if (l < n && a[l] > a[largest]) largest = l;
    if (r < n && a[r] > a[largest]) largest = r;

    if (largest != i) {                          /* parent broke the rule */
        swapInt(a[i], a[largest]);
        maxHeapify(a, n, largest);               /* keep sinking */
    }
}

/* ------------------------------------------------------------
   Problem 42 : delete the ROOT of a max heap
   Move the LAST element to the root, shrink the heap by one,
   then heapify the root back down.
   ------------------------------------------------------------ */
int deleteRoot(int a[], int &n)
{
    if (n <= 0) return -1;

    int root = a[0];
    a[0] = a[n - 1];                 /* last element becomes the new root */
    n--;
    maxHeapify(a, n, 0);
    return root;
}

/* ------------------------------------------------------------
   Problem 44 : turn an unsorted array into a MAX heap
   Heapify every internal node, starting from the LAST one.
   Leaves (index n/2 .. n-1) are already valid heaps of size 1.
   ------------------------------------------------------------ */
void buildMaxHeap(int a[], int n)
{
    for (int i = n / 2 - 1; i >= 0; i--) {
        cout << "     heapify at index " << i << " (value " << a[i] << ") : ";
        maxHeapify(a, n, i);
        printArray(a, n);
    }
}

/* ------------------------------------------------------------
   Problem 45 : HEAP SORT (ascending)
   1. build a max heap
   2. repeatedly swap the root with the last element of the heap,
      shrink the heap, and heapify the root
   ------------------------------------------------------------ */
void heapSort(int a[], int n)
{
    for (int i = n / 2 - 1; i >= 0; i--) maxHeapify(a, n, i);   /* step 1 */

    cout << "     max heap built : ";
    printArray(a, n);

    for (int size = n; size > 1; size--) {                      /* step 2 */
        cout << "     root " << a[0] << " -> position " << size - 1 << " : ";
        swapInt(a[0], a[size - 1]);
        maxHeapify(a, size - 1, 0);
        printArray(a, n);
    }
}

/* ============================ DEMO ============================ */
int main()
{
    /* ---------------- Problem 41 ---------------- */
    int heap[MAX], n = 0;
    int in41[] = { 25, 40, 15, 50, 10, 35, 60, 20 };

    cout << "P41) Max heap, inserting 25 40 15 50 10 35 60 20\n";
    for (int i = 0; i < 8; i++) {
        insertMaxHeap(heap, n, in41[i]);
        cout << "     insert " << in41[i] << " : ";
        printArray(heap, n);
    }
    cout << "     final heap :\n";
    drawHeap(heap, n, 0, 1);
    cout << "\n";

    /* ---------------- Problem 42 ---------------- */
    int h42[] = { 90, 70, 80, 40, 60, 50, 30 };
    int n42   = 7;

    cout << "P42) Max heap ";
    printArray(h42, n42);
    cout << "     before :\n";
    drawHeap(h42, n42, 0, 1);

    int removed = deleteRoot(h42, n42);
    cout << "     deleted root = " << removed << "\n";
    cout << "     after  : ";
    printArray(h42, n42);
    drawHeap(h42, n42, 0, 1);
    cout << "\n";

    /* ---------------- Problem 43 ---------------- */
    int h43[MAX] = { 10, 20, 15, 30, 40, 25 };
    int n43      = 6;

    cout << "P43) Min heap ";
    printArray(h43, n43);
    insertMinHeap(h43, n43, 5);
    cout << "     after inserting 5 : ";
    printArray(h43, n43);
    drawHeap(h43, n43, 0, 1);
    cout << "\n";

    /* ---------------- Problem 44 ---------------- */
    int h44[] = { 12, 7, 25, 15, 28, 33, 18, 10 };
    int n44   = 8;

    cout << "P44) Build a max heap from ";
    printArray(h44, n44);
    buildMaxHeap(h44, n44);
    cout << "     resulting max heap :\n";
    drawHeap(h44, n44, 0, 1);
    cout << "\n";

    /* ---------------- Problem 45 ---------------- */
    int h45[] = { 45, 20, 35, 10, 50, 30, 25 };
    int n45   = 7;

    cout << "P45) Heap sort on ";
    printArray(h45, n45);
    heapSort(h45, n45);
    cout << "     sorted (ascending) : ";
    printArray(h45, n45);
    return 0;
}
