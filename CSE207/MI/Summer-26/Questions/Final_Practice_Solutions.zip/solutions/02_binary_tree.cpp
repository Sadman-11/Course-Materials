/* ============================================================
   CSE207 Practice - Part 2 : BINARY TREE  (Problems 5 - 12)
   Compile: g++ 02_binary_tree.cpp -o 02_binary_tree
   ============================================================ */
#include <iostream>
using namespace std;

struct Node {
    int   data;
    Node *left, *right;
};

Node* newNode(int d)
{
    Node *p  = new Node;
    p->data  = d;
    p->left  = NULL;
    p->right = NULL;
    return p;
}

/* ------------------------------------------------------------
   Problem 5 : min / max number of nodes of a binary tree, height 6
   (Convention used here: height = number of EDGES on the longest
    root-to-leaf path, so a tree of height h has h+1 levels.)

        minimum nodes = h + 1        -> one node per level (a chain)
        maximum nodes = 2^(h+1) - 1  -> every level completely full
   ------------------------------------------------------------ */
int minNodes(int h) { return h + 1; }

int maxNodes(int h)
{
    int p = 1;
    for (int i = 0; i <= h; i++) p *= 2;   /* p = 2^(h+1) */
    return p - 1;
}

/* ------------------------------------------------------------
   Problem 6 : build a binary tree from POSTORDER + INORDER
   Root of a segment = LAST element of its postorder segment.
   ------------------------------------------------------------ */
int search(int in[], int lo, int hi, int key)
{
    for (int i = lo; i <= hi; i++)
        if (in[i] == key) return i;
    return -1;
}

/* postIdx walks the postorder array from the RIGHT end */
Node* buildPostIn(int in[], int post[], int inLo, int inHi, int &postIdx)
{
    if (inLo > inHi) return NULL;

    Node *root = newNode(post[postIdx--]);      /* take root, step left  */
    int   pos  = search(in, inLo, inHi, root->data);

    root->right = buildPostIn(in, post, pos + 1, inHi, postIdx);  /* RIGHT first */
    root->left  = buildPostIn(in, post, inLo, pos - 1, postIdx);
    return root;
}

/* ------------------------------------------------------------
   Problem 11 : build a binary tree from PREORDER + INORDER
   Root of a segment = FIRST element of its preorder segment.
   ------------------------------------------------------------ */
Node* buildPreIn(int in[], int pre[], int inLo, int inHi, int &preIdx)
{
    if (inLo > inHi) return NULL;

    Node *root = newNode(pre[preIdx++]);        /* take root, step right */
    int   pos  = search(in, inLo, inHi, root->data);

    root->left  = buildPreIn(in, pre, inLo, pos - 1, preIdx);     /* LEFT first */
    root->right = buildPreIn(in, pre, pos + 1, inHi, preIdx);
    return root;
}

/* ------------------------------------------------------------
   Problem 12 : height of a binary tree (recursive)
   ------------------------------------------------------------ */
int height(Node *root)
{
    if (root == NULL) return -1;                /* empty tree -> -1 edges */
    int lh = height(root->left);
    int rh = height(root->right);
    return 1 + (lh > rh ? lh : rh);
}

/* ------------------------------------------------------------
   Problem 10 : count leaf nodes (recursive)
   ------------------------------------------------------------ */
int countLeaves(Node *root)
{
    if (root == NULL) return 0;
    if (root->left == NULL && root->right == NULL) return 1;
    return countLeaves(root->left) + countLeaves(root->right);
}

/* ------------------------------------------------------------
   Problem 7 : is the binary tree COMPLETE ?
   Level-order scan: once an empty slot has been seen, no real node
   may appear afterwards. (Plain array used as the queue.)
   ------------------------------------------------------------ */
bool isComplete(Node *root)
{
    if (root == NULL) return true;

    Node *q[100];
    int  front = 0, rear = 0;
    bool seenNull = false;

    q[rear++] = root;
    while (front < rear) {
        Node *cur = q[front++];

        if (cur == NULL) {
            seenNull = true;                    /* a gap was found          */
        } else {
            if (seenNull) return false;         /* node AFTER a gap -> no   */
            q[rear++] = cur->left;
            q[rear++] = cur->right;
        }
    }
    return true;
}

/* ------------------------------------------------------------
   Problem 9 : sum of all LEFT leaves
   A node is a "left leaf" if it is the LEFT child of its parent
   and it has no children of its own.
   ------------------------------------------------------------ */
int sumLeftLeaves(Node *root)
{
    if (root == NULL) return 0;

    int sum = 0;
    if (root->left != NULL &&
        root->left->left == NULL && root->left->right == NULL)
        sum += root->left->data;                /* left child is a leaf   */
    else
        sum += sumLeftLeaves(root->left);       /* otherwise go deeper    */

    sum += sumLeftLeaves(root->right);          /* right subtree may hold */
    return sum;                                 /* left leaves as well    */
}

/* ---------------------- traversals ---------------------- */
void preorder (Node *r) { if (r) { cout << r->data << " "; preorder(r->left);  preorder(r->right); } }
void inorder  (Node *r) { if (r) { inorder(r->left);   cout << r->data << " "; inorder(r->right);  } }
void postorder(Node *r) { if (r) { postorder(r->left); postorder(r->right); cout << r->data << " "; } }

/* same three traversals, printing the values as letters (used in the demo) */
void preorderC (Node *r) { if (r) { cout << (char)r->data << " "; preorderC(r->left);  preorderC(r->right); } }
void inorderC  (Node *r) { if (r) { inorderC(r->left);   cout << (char)r->data << " "; inorderC(r->right);  } }
void postorderC(Node *r) { if (r) { postorderC(r->left); postorderC(r->right); cout << (char)r->data << " "; } }

/* sideways picture: root on the left, right subtree printed on top */
void printTree(Node *r, int depth)
{
    if (r == NULL) return;
    printTree(r->right, depth + 1);
    for (int i = 0; i < depth; i++) cout << "      ";
    cout << (char)r->data << "\n";
    printTree(r->left, depth + 1);
}

/* ------------------------------------------------------------
   Problem 8 : GENERAL tree (a node may have any number of children)
   ------------------------------------------------------------ */
struct GNode {
    char   data;
    GNode *child[5];
    int    nChild;
};

GNode* newGNode(char d)
{
    GNode *p  = new GNode;
    p->data   = d;
    p->nChild = 0;
    return p;
}
void addChild(GNode *parent, GNode *c) { parent->child[parent->nChild++] = c; }

void gPreorder(GNode *r)                        /* root, then children L->R */
{
    if (r == NULL) return;
    cout << r->data << " ";
    for (int i = 0; i < r->nChild; i++) gPreorder(r->child[i]);
}
void gPostorder(GNode *r)                       /* children L->R, then root */
{
    if (r == NULL) return;
    for (int i = 0; i < r->nChild; i++) gPostorder(r->child[i]);
    cout << r->data << " ";
}

/* ============================ DEMO ============================ */
int main()
{
    /* ---------------- Problem 5 ---------------- */
    cout << "P5) Binary tree of height 6 (height counted in EDGES)\n";
    cout << "    minimum nodes = h + 1       = " << minNodes(6) << "\n";
    cout << "    maximum nodes = 2^(h+1) - 1 = " << maxNodes(6) << "\n";
    cout << "    [if height is counted in LEVELS: min = 6, max = 63]\n\n";

    /* ---------------- Problem 6 ---------------- */
    int post6[] = { 'F','E','C','H','G','D','B','A' };
    int in6[]   = { 'F','C','E','A','B','H','D','G' };
    int pIdx    = 7;                             /* last index of postorder */
    Node *t6 = buildPostIn(in6, post6, 0, 7, pIdx);

    cout << "P6) Tree from Postorder = F E C H G D B A , Inorder = F C E A B H D G\n";
    printTree(t6, 1);
    cout << "    check preorder  : "; preorderC(t6);  cout << "\n";
    cout << "    check inorder   : "; inorderC(t6);   cout << "\n";
    cout << "    check postorder : "; postorderC(t6); cout << "\n\n";

    /* ---------------- Problem 7 ---------------- */
    cout << "P7) Is the P6 tree complete ? " << (isComplete(t6) ? "YES" : "NO") << "\n";

    Node *c = newNode('A');                      /* A(B(D,E), C) is complete */
    c->left = newNode('B');  c->right = newNode('C');
    c->left->left = newNode('D');  c->left->right = newNode('E');
    cout << "    Is A(B(D,E),C) complete ?  " << (isComplete(c) ? "YES" : "NO") << "\n\n";

    /* ---------------- Problem 8 ---------------- */
    GNode *L = newGNode('L'), *K = newGNode('K'), *I = newGNode('I'), *H = newGNode('H');
    GNode *A = newGNode('A'), *J = newGNode('J'), *E = newGNode('E'), *F = newGNode('F');
    GNode *G = newGNode('G'), *B = newGNode('B'), *C = newGNode('C'), *D = newGNode('D');
    addChild(L, K); addChild(L, I); addChild(L, H);
    addChild(K, A); addChild(K, J);
    addChild(J, B); addChild(J, C);
    addChild(H, E); addChild(H, F); addChild(H, G);
    addChild(F, D);

    cout << "P8) General tree rooted at L\n";
    cout << "    preorder  : "; gPreorder(L);  cout << "\n";
    cout << "    postorder : "; gPostorder(L); cout << "\n\n";

    /* ---------------- Problem 9 ---------------- */
    Node *t9 = newNode(9);
    t9->left  = newNode(6);   t9->right = newNode(12);
    t9->left->left  = newNode(3);   t9->left->right = newNode(7);
    t9->right->left = newNode(10);
    cout << "P9) Tree  9( 6(3,7) , 12(10,-) )\n";
    cout << "    sum of all left leaves = " << sumLeftLeaves(t9) << "   (3 + 10)\n\n";

    /* ------------- Problems 10 & 12 ------------- */
    cout << "P10) leaf nodes in the P6 tree = " << countLeaves(t6) << "\n";
    cout << "P12) height of the P6 tree     = " << height(t6) << " (edges)\n\n";

    /* ---------------- Problem 11 --------------- */
    int pre11[] = { 'A','B','D','E','C','F' };
    int in11[]  = { 'D','B','E','A','C','F' };
    int qIdx    = 0;
    Node *t11 = buildPreIn(in11, pre11, 0, 5, qIdx);

    cout << "P11) Tree from Preorder = A B D E C F , Inorder = D B E A C F\n";
    printTree(t11, 1);
    cout << "    check preorder  : "; preorderC(t11); cout << "\n";
    cout << "    check inorder   : "; inorderC(t11);  cout << "\n";
    cout << "    height = " << height(t11) << " edges , leaves = " << countLeaves(t11) << "\n";
    return 0;
}
