/* ============================================================
   CSE207 Practice - Part 1 : RECURSION  (Problems 1 - 4)
   Compile: g++ 01_recursion.cpp -o 01_recursion
   ============================================================ */
#include <iostream>
using namespace std;

/* ------------------------------------------------------------
   Problem 1 : Length of a string (recursive definition)

   Recursive definition:
        len("")      = 0                      <-- base case
        len(s)       = 1 + len(rest of s)     <-- general case
   ------------------------------------------------------------ */
int strLength(const char *s)
{
    if (*s == '\0')                 // base case: empty string
        return 0;
    return 1 + strLength(s + 1);    // 1 for current char + rest
}

/* ------------------------------------------------------------
   Problem 2 : Ackermann's number
        A(m,n) = n+1                    if m = 0
        A(m,n) = A(m-1, 1)              if n = 0 and m > 0
        A(m,n) = A(m-1, A(m, n-1))      otherwise
   ------------------------------------------------------------ */
int ackermann(int m, int n)
{
    if (m == 0)
        return n + 1;
    if (n == 0)
        return ackermann(m - 1, 1);
    return ackermann(m - 1, ackermann(m, n - 1));
}

/* ------------------------------------------------------------
   Problem 3 : Count digits of a positive integer
        digits(n) = 1                    if n < 10
        digits(n) = 1 + digits(n/10)     otherwise
   ------------------------------------------------------------ */
int countDigits(int n)
{
    if (n < 10)                     // base case: single digit
        return 1;
    return 1 + countDigits(n / 10); // drop last digit
}

/* ------------------------------------------------------------
   Problem 4 : Sum of elements of an integer array (NO loop)
        sum(a, 0) = 0
        sum(a, n) = a[n-1] + sum(a, n-1)
   ------------------------------------------------------------ */
int arraySum(int a[], int n)
{
    if (n == 0)                     // base case: empty array
        return 0;
    return a[n - 1] + arraySum(a, n - 1);
}

/* ============================ DEMO ============================ */
int main()
{
    /* ---- Problem 1 ---- */
    const char *s = "one two three four five";
    cout << "P1) String : \"" << s << "\"\n";
    cout << "    Length = " << strLength(s) << "\n\n";

    /* ---- Problem 2 ---- */
    cout << "P2) Ackermann test cases\n";
    cout << "    A(2,3) = " << ackermann(2, 3) << "\n";
    cout << "    A(3,0) = " << ackermann(3, 0) << "\n";
    cout << "    A(2,5) = " << ackermann(2, 5) << "\n";
    cout << "    A(0,3) = " << ackermann(0, 3) << "\n\n";

    /* ---- Problem 3 ---- */
    cout << "P3) countDigits(50724) = " << countDigits(50724) << "\n\n";

    /* ---- Problem 4 ---- */
    int a[] = {4, 8, 15, 16, 23, 42};
    int n = 6;
    cout << "P4) Array = {4, 8, 15, 16, 23, 42}\n";
    cout << "    Sum   = " << arraySum(a, n) << "\n";
    return 0;
}
