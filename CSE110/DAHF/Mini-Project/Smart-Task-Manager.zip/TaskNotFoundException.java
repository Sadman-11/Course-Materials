package taskManager;
/**
 * TaskNotFoundException.java
 * Custom exception class for handling invalid task operations.
 * Thrown when a user tries to access a task that doesn't exist.
 * Demonstrates custom exception handling in Java.
 */
public class TaskNotFoundException extends Exception {
    public TaskNotFoundException(String message) {
        super(message);
    }
    public TaskNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
    public TaskNotFoundException(int index, int maxIndex) {
        super("Task not found at index " + index + ". Valid range: 0 to " + maxIndex);
    }
}
