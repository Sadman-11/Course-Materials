package taskManager;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * TaskManager.java
 * Main class for the Smart Task Manager application.
 * Provides a menu-driven console interface for managing tasks.
 * Demonstrates:
 * - Polymorphism (storing different task types in ArrayList<Task>)
 * - Exception handling (try-catch, custom exceptions)
 * - File I/O for data persistence
 */
public class TaskManager {
    private ArrayList<Task> tasks;
    private Scanner scanner;
    private static final String DATA_FILE = "tasks.txt";

    public TaskManager() {
        tasks = new ArrayList<>();
        scanner = new Scanner(System.in);
    }

    public static void main(String[] args) {
        TaskManager manager = new TaskManager();
        manager.loadTasksFromFile();
        manager.run();
    }

    // main function
    public void run() {
        boolean running = true;
        printWelcomeBanner();
        
        while (running) {
            displayMenu();
            
            try {
                System.out.print("Enter your choice: ");
                String input = scanner.nextLine().trim();
                int choice = Integer.parseInt(input);
                
                switch (choice) {
                    case 1:
                        addNewTask();
                        break;
                    case 2:
                        markTaskCompleted();
                        break;
                    case 3:
                        displayAllTasks();
                        break;
                    case 4:
                        displayCompletedTasks();
                        break;
                    case 5:
                        displayPendingTasks();
                        break;
                    case 6:
                        saveTasksToFile();
                        System.out.println("\n✓ Tasks saved successfully!");
                        break;
                    case 7:
                        saveTasksToFile();
                        running = false;
                        System.out.println("\n════════════════════════════════════════");
                        System.out.println("  Thank you for using Smart Task Manager!");
                        System.out.println("  Your tasks have been saved. Goodbye!");
                        System.out.println("════════════════════════════════════════\n");
                        break;
                    default:
                        System.out.println("\n⚠ Invalid choice! Please enter a number between 1 and 7.");
                }
            } catch (NumberFormatException e) {
                System.out.println("\n⚠ Invalid input! Please enter a valid number.");
            } catch (InputMismatchException e) {
                System.out.println("\n⚠ Invalid input format! Please try again.");
                scanner.nextLine();
            }
        }
        
        scanner.close();
    }

    private void printWelcomeBanner() {
    	System.out.println("\n");
        System.out.println("╔══════════════════════════════════════════════╗");
        System.out.println("║                                              ║");
        System.out.println("║      	★ SMART TASK MANAGER *                 ║");
        System.out.println("║                                              ║");
        System.out.println("║   Organize your work and personal tasks!     ║");
        System.out.println("║                                              ║");
        System.out.println("╚══════════════════════════════════════════════╝");
        System.out.println("\n");
    }

    private void displayMenu() {
        System.out.println("\n┌──────────────────────────────────────────────┐");
        System.out.println("│              MAIN MENU                       │");
        System.out.println("├──────────────────────────────────────────────┤");
        System.out.println("│  1. Add a New Task                           │");
        System.out.println("│  2. Mark Task as Completed                   │");
        System.out.println("│  3. Display All Tasks                        │");
        System.out.println("│  4. Display Completed Tasks                  │");
        System.out.println("│  5. Display Pending Tasks                    │");
        System.out.println("│  6. Save Tasks to File                       │");
        System.out.println("│  7. Exit                                     │");
        System.out.println("└──────────────────────────────────────────────┘");
    }

 
    private void addNewTask() {
        System.out.println("\n═══════ ADD NEW TASK ═══════\n");
        System.out.print("Enter task title: ");
        String title = scanner.nextLine().trim();
        
        if (title.isEmpty()) {
            System.out.println("\n⚠ Title cannot be empty. Task not created.");
            return;
        }
        
        System.out.print("Enter task description: ");
        String description = scanner.nextLine().trim();
        
        System.out.println("\nSelect task type:");
        System.out.println("  1. Work Task");
        System.out.println("  2. Personal Task");
        System.out.print("Enter choice (1 or 2): ");
        
        try {
            String typeInput = scanner.nextLine().trim();
            int taskType = Integer.parseInt(typeInput);
            
            Task newTask;
            
            if (taskType == 1) {
                newTask = new WorkTask(title, description);
                tasks.add(newTask);
                System.out.println("\n✓ Work Task added successfully!");
            } else if (taskType == 2) {
                newTask = new PersonalTask(title, description);
                tasks.add(newTask);
                System.out.println("\n✓ Personal Task added successfully!");
            } else {
                System.out.println("\n⚠ Invalid task type. Task not created.");
                return;
            }
            
            System.out.println("  Task ID: " + newTask.getId());
            System.out.println("  Title: " + newTask.getTitle());
            
        } catch (NumberFormatException e) {
            System.out.println("\n⚠ Invalid input! Please enter 1 or 2.");
        }
    }

    private void markTaskCompleted() {
        System.out.println("\n═══════ MARK TASK COMPLETED ═══════\n");
        
        if (tasks.isEmpty()) {
            System.out.println("No tasks available. Add some tasks first!");
            return;
        }
        
        System.out.println("Available Tasks:");
        System.out.println("─────────────────────────────────────────");
        
        for (int i = 0; i < tasks.size(); i++) {
            Task task = tasks.get(i);
            String status = task.isCompleted() ? "[✓]" : "[ ]";
            String type = task.getTaskType().equals("WorkTask") ? "Work" : "Personal";
            System.out.printf("  %d. %s [%s] %s%n", i, status, type, task.getTitle());
        }
        
        System.out.println("─────────────────────────────────────────");
        System.out.print("\nEnter the index of the task to mark as completed: ");
        
        try {
            String indexInput = scanner.nextLine().trim();
            int index = Integer.parseInt(indexInput);
            validateTaskIndex(index);
            Task task = tasks.get(index);
            if (task.isCompleted()) {
                System.out.println("\n⚠ This task is already marked as completed.");
            } else {
                task.setCompleted(true);
                System.out.println("\n✓ Task marked as completed!");
                System.out.println("  Title: " + task.getTitle());
            }
            
        } catch (NumberFormatException e) {
            System.out.println("\n⚠ Invalid input! Please enter a valid number.");
        } catch (TaskNotFoundException e) {
            System.out.println("\n⚠ Error: " + e.getMessage());
        }
    }

    private void validateTaskIndex(int index) throws TaskNotFoundException {
        if (index < 0 || index >= tasks.size()) {
            throw new TaskNotFoundException(index, tasks.size() - 1);
        }
    }

    private void displayAllTasks() {
        System.out.println("\n═══════ ALL TASKS ═══════\n");
        
        if (tasks.isEmpty()) {
            System.out.println("No tasks found. Start by adding some tasks!");
            return;
        }
        
        System.out.println("Total tasks: " + tasks.size() + "\n");
        
        // Display each task's details
        for (Task task : tasks) {
            System.out.println(task.getDetails());
            System.out.println();
        }
    }

    private void displayCompletedTasks() {
        System.out.println("\n═══════ COMPLETED TASKS ═══════\n");
        
        ArrayList<Task> completedTasks = new ArrayList<>();
        
        for (Task task : tasks) {
            if (task.isCompleted()) {
                completedTasks.add(task);
            }
        }
        
        if (completedTasks.isEmpty()) {
            System.out.println("No completed tasks yet. Keep working on your tasks!");
            return;
        }
        
        System.out.println("Completed tasks: " + completedTasks.size() + "\n");
        
        for (Task task : completedTasks) {
            System.out.println(task.getDetails());
            System.out.println();
        }
    }

    private void displayPendingTasks() {
        System.out.println("\n═══════ PENDING TASKS ═══════\n");
        
        ArrayList<Task> pendingTasks = new ArrayList<>();
        
        for (Task task : tasks) {
            if (!task.isCompleted()) {
                pendingTasks.add(task);
            }
        }
        
        if (pendingTasks.isEmpty()) {
            System.out.println("No pending tasks! Great job completing all your tasks!");
            return;
        }
        
        System.out.println("Pending tasks: " + pendingTasks.size() + "\n");
        
        for (Task task : pendingTasks) {
            System.out.println(task.getDetails());
            System.out.println();
        }
    }

    private void saveTasksToFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(DATA_FILE))) {
            for (Task task : tasks) {
                writer.println(task.toFileString());
            }
        } catch (IOException e) {
            System.out.println("\n⚠ Error saving tasks: " + e.getMessage());
        }
    }

    private void loadTasksFromFile() {
        File file = new File(DATA_FILE);
        
        if (!file.exists()) {
            return;
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            int maxId = 0;
            
            while ((line = reader.readLine()) != null) {
                Task task = parseTaskFromLine(line);
                if (task != null) {
                    tasks.add(task);
                    if (task.getId() > maxId) {
                        maxId = task.getId();
                    }
                }
            }
            
            Task.resetIdCounter(maxId + 1);
            
            if (!tasks.isEmpty()) {
                System.out.println("✓ Loaded " + tasks.size() + " task(s) from file.");
            }
            
        } catch (IOException e) {
            System.out.println("⚠ Error loading tasks: " + e.getMessage());
        }
    }

    // A custom parser for reading tasks from file
    private Task parseTaskFromLine(String line) {
        try {
            String[] parts = line.split("\\|");
            
            if (parts.length < 5) {
                return null;
            }
            
            String type = parts[0];
            int id = Integer.parseInt(parts[1]);
            String title = parts[2];
            String description = parts[3];
            boolean isCompleted = Boolean.parseBoolean(parts[4]);
            
            if (type.equals("WorkTask")) {
                return new WorkTask(id, title, description, isCompleted);
            } else if (type.equals("PersonalTask")) {
                return new PersonalTask(id, title, description, isCompleted);
            }
            
        } catch (Exception e) {
            System.out.println("⚠ Error parsing task: " + line);
        }
        
        return null;
    }
}
