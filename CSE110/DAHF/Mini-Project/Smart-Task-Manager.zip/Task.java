package taskManager;
/**
 * Task.java
 * Base class representing a task in the Smart Task Manager.
 * Demonstrates encapsulation with private fields and public getters/setters.
 * This class serves as the parent class for WorkTask and PersonalTask.
 */
public abstract class Task {
    // encapsulated fields
    private int id;
    private String title;
    private String description;
    private boolean isCompleted;
    // a static counter
    private static int idCounter = 1;

    // Abstract methods to be implemented by subclasses
    public abstract String getDetails();
    public abstract String getTaskType();

    public Task(String title, String description) {
        this.id = idCounter++;
        this.title = title;
        this.description = description;
        this.isCompleted = false;
    }

    public Task(int id, String title, String description, boolean isCompleted) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.isCompleted = isCompleted;
        // Update counter to avoid ID conflicts
        if (id >= idCounter) {
            idCounter = id + 1;
        }
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isCompleted() {
        return isCompleted;
    }

    public void setCompleted(boolean completed) {
        this.isCompleted = completed;
    }

    public String toFileString() {
        return getTaskType() + "|" + id + "|" + title + "|" + description + "|" + isCompleted;
    }

    @Override
    public String toString() {
        return getDetails();
    }

    public static void resetIdCounter(int startId) {
        idCounter = startId;
    }
}
