package taskManager;
/**
 * WorkTask.java
 * Subclass of Task representing a work-related task.
 * Demonstrates inheritance by extending the Task class.
 * Implements polymorphism by overriding the getDetails() method.
 */
public class WorkTask extends Task {

    public WorkTask(String title, String description) {
        super(title, description);
    }

    public WorkTask(int id, String title, String description, boolean isCompleted) {
        super(id, title, description, isCompleted);
    }

    @Override
    public String getTaskType() {
        return "WorkTask";
    }

    @Override
    public String getDetails() {
        String status = isCompleted() ? "✓ Completed" : "○ Pending";
        return String.format(
            "┌─────────────────────────────────────────┐\n" +
            "│ [WORK TASK] ID: %-24d│\n" +
            "├─────────────────────────────────────────┤\n" +
            "│ Title: %-32s│\n" +
            "│ Description: %-27s│\n" +
            "│ Status: %-31s│\n" +
            "└─────────────────────────────────────────┘",
            getId(),
            truncate(getTitle(), 32),
            truncate(getDescription(), 27),
            status
        );
    }

    private String truncate(String str, int maxLength) {
        if (str == null) return "";
        if (str.length() <= maxLength) return str;
        return str.substring(0, maxLength - 3) + "...";
    }
}
