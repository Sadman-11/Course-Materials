package taskManager;

/**
 * PersonalTask.java
 * Subclass of Task representing a personal task.
 * In this file we override the getDetails method to provide a custom string representation
 */
public class PersonalTask extends Task {

    public PersonalTask(String title, String description) {
        super(title, description);
    }

    public PersonalTask(int id, String title, String description, boolean isCompleted) {
        super(id, title, description, isCompleted);
    }

    @Override
    public String getTaskType() {
        return "PersonalTask";
    }

    @Override
    public String getDetails() {
        String status = isCompleted() ? "✓ Completed" : "○ Pending";
        return String.format(
            "╔═════════════════════════════════════════╗\n" +
            "║ [PERSONAL TASK] ID: %-20d║\n" +
            "╠═════════════════════════════════════════╣\n" +
            "║ Title: %-32s║\n" +
            "║ Description: %-27s║\n" +
            "║ Status: %-31s║\n" +
            "╚═════════════════════════════════════════╝",
            getId(),
            truncate(getTitle(), 32),
            truncate(getDescription(), 27),
            status
        );
    }

    private String truncate(String str, int maxLength) {
        if (str == null) return "";
        if (str.length() <= maxLength) return str;
        return str.substring(0, maxLength - 3) + "...";
    }
}
